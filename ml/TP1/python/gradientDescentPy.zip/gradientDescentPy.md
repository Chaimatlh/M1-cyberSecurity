# First program of batch gradient descent 



```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Loading data
data = pd.read_csv('Salary_Data.csv')
x = data["YearsExperience"].values
y = data["Salary"].values

# Cost function
def cost(x, y, params):
    m = len(x) # is the number of training exemples 
    h = params[0] + params[1] * x
    total_cost = (1 / (2 * m)) * np.sum((h - y) ** 2)
    return total_cost

# Gradient Descent function
def gradient_descent(x, y, params, learning_rate, num_iterations):
    m = len(x)
    for i in range(num_iterations):
        h = params[0] + params[1] * x # f function = w*x + b
        params[0] -= (learning_rate / m) * np.sum(h - y) #update of b 
        params[1] -= (learning_rate / m) * np.sum((h - y) * x) #update of w  
        print(f'Iteration {i+1}, Cost: {cost(x, y, params)}')
    return params

# Running gradient descent
params = np.zeros(2)
learning_rate = 0.01
num_iterations = 100
params = gradient_descent(x, y, params, learning_rate, num_iterations)
print(f'Final Parameters: {params}')
```

    Iteration 1, Cost: 1344612525.8413546
    Iteration 2, Cost: 582933639.1249906
    Iteration 3, Cost: 278595825.9816314
    Iteration 4, Cost: 156901936.81054017
    Iteration 5, Cost: 108149191.53202371
    Iteration 6, Cost: 88526795.50639796
    Iteration 7, Cost: 80538511.12387827
    Iteration 8, Cost: 77197055.80937985
    Iteration 9, Cost: 75711992.71002823
    Iteration 10, Cost: 74968933.07002829
    Iteration 11, Cost: 74522833.02695376
    Iteration 12, Cost: 74195957.6330042
    Iteration 13, Cost: 73917324.17093241
    Iteration 14, Cost: 73658582.39816462
    Iteration 15, Cost: 73408407.74554898
    Iteration 16, Cost: 73162275.01092048
    Iteration 17, Cost: 72918374.39160368
    Iteration 18, Cost: 72675980.51521406
    Iteration 19, Cost: 72434801.09739314
    Iteration 20, Cost: 72194716.82236984
    Iteration 21, Cost: 71955677.46187694
    Iteration 22, Cost: 71717660.38925987
    Iteration 23, Cost: 71480654.01166646
    Iteration 24, Cost: 71244651.1534976
    Iteration 25, Cost: 71009646.41398284
    Iteration 26, Cost: 70775635.11185877
    Iteration 27, Cost: 70542612.86387193
    Iteration 28, Cost: 70310575.41640493
    Iteration 29, Cost: 70079518.57818976
    Iteration 30, Cost: 69849438.19339187
    Iteration 31, Cost: 69620330.13081625
    Iteration 32, Cost: 69392190.27955258
    Iteration 33, Cost: 69165014.54719205
    Iteration 34, Cost: 68938798.85907094
    Iteration 35, Cost: 68713539.15792523
    Iteration 36, Cost: 68489231.40370873
    Iteration 37, Cost: 68265871.5734771
    Iteration 38, Cost: 68043455.66129845
    Iteration 39, Cost: 67821979.67817467
    Iteration 40, Cost: 67601439.65196675
    Iteration 41, Cost: 67381831.62732287
    Iteration 42, Cost: 67163151.66560662
    Iteration 43, Cost: 66945395.84482651
    Iteration 44, Cost: 66728560.25956535
    Iteration 45, Cost: 66512641.02091024
    Iteration 46, Cost: 66297634.256382965
    Iteration 47, Cost: 66083536.10987019
    Iteration 48, Cost: 65870342.74155465
    Iteration 49, Cost: 65658050.32784609
    Iteration 50, Cost: 65446655.06131272
    Iteration 51, Cost: 65236153.150612965
    Iteration 52, Cost: 65026540.820427485
    Iteration 53, Cost: 64817814.31139133
    Iteration 54, Cost: 64609969.88002675
    Iteration 55, Cost: 64403003.798675776
    Iteration 56, Cost: 64196912.355433695
    Iteration 57, Cost: 63991691.85408209
    Iteration 58, Cost: 63787338.61402292
    Iteration 59, Cost: 63583848.970212206
    Iteration 60, Cost: 63381219.27309457
    Iteration 61, Cost: 63179445.88853751
    Iteration 62, Cost: 62978525.19776649
    Iteration 63, Cost: 62778453.59729976
    Iteration 64, Cost: 62579227.49888402
    Iteration 65, Cost: 62380843.32942986
    Iteration 66, Cost: 62183297.53094766
    Iteration 67, Cost: 61986586.560484014
    Iteration 68, Cost: 61790706.89005783
    Iteration 69, Cost: 61595655.00659749
    Iteration 70, Cost: 61401427.41187738
    Iteration 71, Cost: 61208020.622455515
    Iteration 72, Cost: 61015431.16961088
    Iteration 73, Cost: 60823655.599281326
    Iteration 74, Cost: 60632690.47200141
    Iteration 75, Cost: 60442532.36284104
    Iteration 76, Cost: 60253177.861343786
    Iteration 77, Cost: 60064623.57146578
    Iteration 78, Cost: 59876866.11151487
    Iteration 79, Cost: 59689902.11408983
    Iteration 80, Cost: 59503728.22602025
    Iteration 81, Cost: 59318341.10830605
    Iteration 82, Cost: 59133737.43605778
    Iteration 83, Cost: 58949913.898437016
    Iteration 84, Cost: 58766867.19859692
    Iteration 85, Cost: 58584594.05362299
    Iteration 86, Cost: 58403091.194474556
    Iteration 87, Cost: 58222355.36592569
    Iteration 88, Cost: 58042383.32650714
    Iteration 89, Cost: 57863171.8484481
    Iteration 90, Cost: 57684717.71761827
    Iteration 91, Cost: 57507017.733470246
    Iteration 92, Cost: 57330068.70898218
    Iteration 93, Cost: 57153867.47060058
    Iteration 94, Cost: 56978410.858183324
    Iteration 95, Cost: 56803695.72494304
    Iteration 96, Cost: 56629718.93739073
    Iteration 97, Cost: 56456477.37527951
    Iteration 98, Cost: 56283967.93154854
    Iteration 99, Cost: 56112187.51226762
    Iteration 100, Cost: 55941133.03658121
    Final Parameters: [ 6481.91749872 12315.52743012]


# this is the linear regression curve 



```python


# Plotting the data points
plt.scatter(x, y, color='blue', label='Actual Data')

# Plotting the regression curve
regression_curve = params[0] + params[1] * x
plt.plot(x, regression_curve, color='red', label='Regression Curve')

# Adding labels and title
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.title('Experience vs. Salary')

# Displaying the legend
plt.legend()

# Displaying the graph
plt.show()

# Printing the final parameters
#print(f'Final Parameters: {params}')
```


    
![png](output_3_0.png)
    



```python

```
